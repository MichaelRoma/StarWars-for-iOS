//
//  GamePlay.swift
//  StarWars
//
//  Created by Aleksey Rochev (Netology) on 19.11.2019.
//  Copyright © 2019 Aleksey Rochev (Netology). All rights reserved.
//

import Foundation

class GamePlay {
    
    //MARK: - Properties
    
    private let space = Space()
    
    func play() {
        print("Давным давно в далекой галактике")
        
        let deathStarPoint = Point.generate()
        let deathStar = DeathStar(coordinate: deathStarPoint)
        deathStar.shootHandler = space
        
        space.add(object: deathStar)
        
        let darthVaderPoint = Point.generate()
        let darthVader = VaderShip(coordinate: darthVaderPoint)
        darthVader.shootHandler = space
               
        space.add(object: darthVader)
        
        let xWing1Point = Point.generate()
        let xWing1 = XWing(coordinate: xWing1Point, name: "Xwing1")
        xWing1.shootHandler = space

        space.add(object: xWing1)
        
      
        let xWing2Point = Point.generate()
        let xWing2 = XWing(coordinate: xWing2Point, name: "Xwing2")
        xWing2.shootHandler = space
                
        space.add(object: xWing2)
        
        let xWing3Point = Point.generate()
        let xWing3 = XWing(coordinate: xWing3Point, name: "Xwing3")
        xWing3.shootHandler = space
                
        space.add(object: xWing3)
        
        let radarPoint = Point.generate()
        let radar = Radar(coordinate: radarPoint)
     //   print(radar.coordinate)
                
        radar.datasource = space
        radar.observers = [xWing1, darthVader, xWing2, deathStar, xWing3]
        radar.toggle()        
        space.add(object: radar)
        
       
    }
    
    deinit {
        print("Game Over")
    }
}


/*
 Общий анализ:
 1) в игре по умолчанию могут победить только Jedi. Данное услови прописано в файле Radar.swift строка 95.
 2) Заявленно различное оружие, но устанавливается только SuperLaser(), это можно определить в описании классов XWing и DeathStar
 3) Не учитывается расстояние между объектами, это пункт задания 1
 4) Баланс Сил Нарушен!!!)))
 
 Начнем выполнять Задание 1
Раскомментируем свойство distance в протоколе Weapons. После этого если не внести изменения в коллекции которые его поддерживают, будет ошибка компиляции, нас интересуют следующие коллекции:
 структура SuperLazer (WeponsEmpire.swift)
 структура Bomb (WeponsJedi.swift)
 структура LazerBlaster (WeponsJedi.swift)
 
 Внесем изменения, просто добавим это свойство в каждую из структур для поддержки протокола Weapens.
 Теперь код компилируется, но изменений не будет, так как мы не используем данное свойство.
 Наполним свойство distance смыслом.
  distance - свойство оружия, которое указывает на каком максимальном расстоянии должны находиться объекты, чтоб был произведен выстрел и нанесены повреждения.
 Давайте добавим код для реализации свойства distance.
 1) В файле Starship.swift, строка 82, реализуем функцию, которая будет считать расстояние между обьектами, на основании их координат.
 2) Добавим механизм сравнения истинного расстояния и дальности стрельбы орудия, которые указываются в свойстве distance.
 Добавили в Starship.swift, строка 69 - 78. В данном коде вычисляем раельное расстояние, затем сравниваем с дистанцией на которую может стрелять орудия, если реальная дистанция больше, то стрельбы не происходит и стреляющий меняет свои координаты с помощью Poin.generate()
 Задание 1 ЗАКОНЧЕНО
 
 Задание 2
 Создав расширение для Вейдера и звезды смерти, использовал обработку ошибок.
 Так же попробовал сделать это в функции checkGameOver, но что-то не получилось, оставил код и закоментил его. Посмотрите пожалуйста, может будут идеи как его закончить.
 
 Задание 3
 Добавим новый корабль для Империи, в файл StarshipsEmpire.swift, новый класс
 VaderShip и добавим Дарта Вейдера на поле боя.
 Так же изменим вооружение кораблей и доавим уникальное оружие для Вейдера! 
 Дополнительно добавили 2 корабля для Джедаев.
 Итого на поле боя 5 объектов!
 Теперь заставим всех участвовать в бою, изменив код в Radar.swift( примерные строки 90), а именно в функции  sendSignal()
 Для этого пишем функцию letsShootByTurn.
 Так же в строке 46-47 observers сделаем хранилищем, НО учтем, что он теперь указывает сильной ссылкой на звездные корабли, это мы компенсируем в функции letsShootByTurn.
 Так же реализуем функцию checkGameOver, которая будет проверять массив и когда там остануться только корабли одной фракции, произойдет остановка игры.
 
 Как вывод могу сказать, что научилася разбираться в чужом коде, хотя есть моменты, которые не совсем понятны. Так же необходимо больше уделить внимане теме обработка ошибок.
 
 */

