//
//  SpaceObserver.swift
//  StarWars
//
//  Created by Aleksey Rochev (Netology) on 19.11.2019.
//  Copyright © 2019 Aleksey Rochev (Netology). All rights reserved.
//

import Foundation

protocol RadarObserver: AnyObject {
    func detected(object: SpaceObject)
}

protocol Togglable {
    mutating func toggle()
}

class Radar: SpaceObject, Togglable {
    
    // MARK: - Constants
    
    private enum  Constants {
        static let timeInterval: TimeInterval = 1
    }
    
    private enum Status: Togglable {
        case on
        case off
        
        mutating func toggle() {
            switch self {
            case .off:
                self = .on
            case .on:
                self = .off
            }
        }
    }
    
    // MARK: - Properties
    
    var coordinate: Point
    var health: Int = 1
    
   // weak var observer: RadarObserver? // Добавил массив ниже
    var observers:[RadarObserver]?  // я добавил
    weak var datasource: Displayable?
    
    private var timer: Timer?
    private var status = Status.off {
        didSet {
            switch status {
            case .on:
                startTimer()
            case .off:
                stopTimer()
            }
        }
    }
        
    // MARK: Lifecycle
    
    init(coordinate: Point) {
        self.coordinate = coordinate
    }
    
    deinit {
        print("Radar is dead")
    }
    
    func toggle() {
        status.toggle()
    }
    
    private func startTimer() {
        timer = Timer.scheduledTimer(timeInterval: Constants.timeInterval,
                                          target: self,
                                          selector: #selector(self.sendSignal),
                                          userInfo: nil,
                                          repeats: true)
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
        
    @objc
    private func sendSignal() {
        
            let rect = Rect.generate()
            print("Сканирую пространство \(rect)")
            if let objects = datasource?.expose(for: rect), !objects.isEmpty {
                print("Ага! Попался \(objects)")
                if let starship = objects.first as? StarshipImp/*,
                starship.fraction == .empare*/ { //Эту строку оставил для напоминания, что тут было
                    print("\(starship) - В меня стреляют")
                    letsShootByTurn(starship, &observers)
                    switch checkGameOver(observers) {
                    case true:
                        print("Empare Win, all Jedis are Dead")
                        stopTimer()
                    case false:
                        print("Jadi Win, all Empare are Dead")
                        stopTimer()
                    default: return
                    }
                }
            }
        }
    }

//функция, которая перебирает все обьекты и делает выстрел.
func letsShootByTurn(_ starship: StarshipImp, _ observers: inout [RadarObserver]?) {
    
    var buffer = 0
    for (index, value) in (observers?.enumerated())! {
        let a =  value as! StarshipImp
        guard a.name != starship.name
            else {
                buffer = index
                continue
        }
        guard a.fraction != starship.fraction else { continue }
        print("\(value) Я стреляю")
        value.detected(object: starship)
    }
    
    guard starship.health > 0 else { observers?.remove(at: buffer)
        return }
    
    //Код, который выводит список участников битвы и их здоровье, можно включить если надо
//        for i in observers! {
//            let a = i as! StarshipImp
//            print("\(a) + \(a.health)")
//        }
}

// Проверяет состояние вселенной и показывает, кто выиграл
func checkGameOver(_ observers: [RadarObserver]?) /* throws */-> Bool? {
    
//    enum FinishGame: Error {
//        case EmpareWin
//        case JediWin
//    }

    var buffer = [StarshipImp]()
    for value in observers!{
        buffer.append(value as! StarshipImp)
    }
 
    guard buffer.contains(where: {$0.fraction != .empare}) else {
        return true
      /*  throw FinishGame.JediWin  */  }
    
    guard buffer.contains(where: {$0.fraction != .jedi}) else {
        return false
      /*    throw FinishGame.EmpareWin */  }
   return nil
}
